package ch.endte.syncmatica.communication;

public enum MessageType {
    SUCCESS,
    INFO,
    WARNING,
    ERROR
}
