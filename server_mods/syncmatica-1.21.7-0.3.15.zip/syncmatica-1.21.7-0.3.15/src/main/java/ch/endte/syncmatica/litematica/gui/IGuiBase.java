package ch.endte.syncmatica.litematica.gui;

import java.util.List;

import fi.dy.masa.malilib.gui.button.ButtonBase;

public interface IGuiBase
{
    List<ButtonBase> getButtons();
}
