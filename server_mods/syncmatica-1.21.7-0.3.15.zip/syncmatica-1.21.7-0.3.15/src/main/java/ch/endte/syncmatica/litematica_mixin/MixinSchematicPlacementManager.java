package ch.endte.syncmatica.litematica_mixin;

//@Mixin(SchematicPlacementManager.class)
public interface MixinSchematicPlacementManager
{
//    @Invoker(value = "onPrePlacementChange", remap = false)
//    void preSubregionChange(SchematicPlacement schematicPlacement);
}
