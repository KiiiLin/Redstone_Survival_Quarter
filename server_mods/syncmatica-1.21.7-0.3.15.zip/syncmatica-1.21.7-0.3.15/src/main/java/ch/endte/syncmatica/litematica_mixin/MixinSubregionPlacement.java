package ch.endte.syncmatica.litematica_mixin;

//@Mixin(SubRegionPlacement.class)
public interface MixinSubregionPlacement {
//    @Accessor(value = "defaultPos", remap = false)
//    BlockPos getDefaultPosition();
//
//    @Accessor(value = "pos", remap = false)
//    void setBlockPosition(BlockPos pos);
//
//    @Accessor(value = "rotation", remap = false)
//    void setBlockRotation(BlockRotation pos);
//
//    @Accessor(value = "mirror", remap = false)
//    void setBlockMirror(BlockMirror pos);
//
//    @Invoker(value = "resetToOriginalValues", remap = false)
//    void reset();
}
